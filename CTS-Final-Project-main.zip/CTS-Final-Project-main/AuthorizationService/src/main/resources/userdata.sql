INSERT INTO userdata (userid,upassword,uname) VALUES ('admin','pwd','admin');
