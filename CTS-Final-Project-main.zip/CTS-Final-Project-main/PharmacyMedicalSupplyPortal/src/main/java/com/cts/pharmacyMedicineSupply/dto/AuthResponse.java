package com.cts.pharmacyMedicineSupply.dto;

public class AuthResponse {
	private String uid;
	private String name;
	private boolean isValid;
}
