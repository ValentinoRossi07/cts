package com.cts.pharmacyMedicineSupply;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmacyMedicalSupplyPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
