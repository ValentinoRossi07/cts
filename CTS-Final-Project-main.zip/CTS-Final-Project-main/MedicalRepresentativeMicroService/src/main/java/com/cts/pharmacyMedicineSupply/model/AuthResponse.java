package com.cts.pharmacyMedicineSupply.model;

public class AuthResponse {
	private String uid;
	private String name;
	private boolean isValid;
}
