package com.cts.pharmacyMedicineSupply.model;

import java.util.List;

//import javax.persistence.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
//@Entity
@AllArgsConstructor
@NoArgsConstructor
public class MedicalRep {

	private String medicalRepName;
	private String contactNumber;
}
