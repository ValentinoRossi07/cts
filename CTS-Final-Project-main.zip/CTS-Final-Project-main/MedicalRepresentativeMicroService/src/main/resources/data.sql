insert into doctor(id,doctorname,contactnumber,treatingailment) values(1,'D1','9884122113','Orthopaedics');
insert into doctor(id,doctorname,contactnumber,treatingailment) values(2,'D2','9884122113','General');
insert into doctor(id,doctorname,contactnumber,treatingailment) values(3,'D3','9884122113','General');
insert into doctor(id,doctorname,contactnumber,treatingailment) values(4,'D4','9884122113','Orthopaedics');
insert into doctor(id,doctorname,contactnumber,treatingailment) values(5,'D5','9884122113','Gynaecology');
