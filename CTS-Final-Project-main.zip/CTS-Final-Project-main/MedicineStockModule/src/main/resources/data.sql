insert into medicine values ('Orthoherb','Eranda','2021-07-30',8000,'Orthopaedics');
insert into medicine values ('Cholecalciferol','ergocalciferolD2','2021-08-31',10000,'Orthopaedics');
insert into medicine values ('Gaviscon','sodium alginate','2022-02-28',20000,'General');
insert into medicine values ('Dolo-650','sodium alginate','2022-10-30',7000,'General');
insert into medicine values ('Cyclopam','Dicyclomine hydrochloride','2023-03-10',5000,'Gynaecology');
insert into medicine values ('Hilact','Asparagus racemosus','2021-12-31',15000,'Gynaecology');